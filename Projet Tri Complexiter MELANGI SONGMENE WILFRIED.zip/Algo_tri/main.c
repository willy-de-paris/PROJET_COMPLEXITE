#include <stdio.h>
#include <stdlib.h>
#include <time.h>       // for clock_t, clock(), CLOCKS_PER_SEC
#include <unistd.h>     // for sleep()
#define TRUE 1
#define FALSE 0
/* D�finition des fonctions de tri */
void temp(){
    // pour stocker le temps d'exécution du code
    double time_spent = 0.0;

    clock_t begin = clock();

    // faire des trucs ici
    sleep(3);

    clock_t end = clock();

    // calcule le temps écoulé en trouvant la différence (end - begin) et
    // divisant la différence par CLOCKS_PER_SEC pour convertir en secondes
    time_spent += (double)(end - begin) / CLOCKS_PER_SEC;

    printf("Le temp d'execution est : %f seconds\n", time_spent);

}
/// tri � bulle croissante
void tri_a_bulle_c(int *t,int n){
    int j =0;int tmp =0;int test =1;

    while(test){
        test = FALSE;
        for(j =0; j < n-1; j++){
            if(t[j] > t[j+1]){
                    tmp = t[j+1];
                    t[j+1] = t[j];t[j] = tmp;
                    test = TRUE;
            }
        }
    }
    temp();
}
/// tri � bulle
void tri_a_bulle_d(int *t,int n){
    int j =0;int tmp =0;int test =1;

    while(test){
        test = FALSE;
        for(j =n-1; j >0; j--){
            if(t[j] > t[j-1]){
                    tmp = t[j-1];
                    t[j-1] = t[j];
                    t[j] = tmp;
                    test = TRUE;
            }
        }
    }
    temp();
}

/// tri par s�lection croissance
void tri_selection_c(int *t, int n){
        int i, min, j , tmp;

        for(i =0; i < n -1; i++){
                min = i;
                for(j = i+1; j < n ; j++)
                    if(t[j] < t[min])
                        min = j;
                if(min != i){
                        tmp = t[i];
                        t[i] = t[min];
                        t[min] = tmp;
                }
        }
        temp();
}
/// tri par s�lection descroissance
void tri_selection_d(int *t, int n){
        int i, min, j , tmp;

        for(i =n-1; i <0; i--){
                min = i;
                for(j = i-1; j >0 ; j--)
                    if(t[j] > t[min])
                        min = j;
                if(min != i){
                        tmp = t[i];
                        t[i] = t[min];
                        t[min] = tmp;
                }
        }
        temp();
}


/// tri par insertion croissance
void tri_insertion_c(int *t,int n){
        int i,p,j;
        int x;

        for(i =1; i < n; i++){
            x = t[i];p = i-1;
            while(t[p] > x && p-- >0){}
            p++;
            for(j = i-1; j >= p; j--){
                t[j+1] = t[j];
            }
            t[p] = x;
        }
        temp();
}
/// tri par insertion
void tri_insertion_d(int *t,int n){
int i,j,x;

    for(i=1;i<=n-1;i++)
  {
      x=t[i];
      j=i;
      while((j>0) &&(t[j-1]<x))
      {
        t[j]=t[j-1];
        j=j-1;
      }
      t[j]=x;
  }
    temp();
}


void permuter(int *a, int *b) {
    int tmp;
    tmp = *a;
    *a = *b;
    *b = tmp;
}

void triRapid(int tab[], int first, int last) {
    int pivot, i, j;

    if(first < last) {
        pivot = first;
        i = first;
        j = last;
        while (i < j) {
            while(tab[i] <= tab[pivot] && i < last)
                i++;
            while(tab[j] > tab[pivot])
                j--;
            if(i < j) {
                permuter(&tab[i], &tab[j]);
            }
        }
        permuter(&tab[pivot], &tab[j]);
        triRapid(tab, first, j - 1);
        triRapid(tab, j + 1, last);
    }
    temp();
}

void triFusion(int i, int j, int tab[], int tmp[]) {

    if(j <= i){ return;}

    int m = (i + j) / 2;

    triFusion(i, m, tab, tmp);     //trier la moitié gauche récursivement
    triFusion(m + 1, j, tab, tmp); //trier la moitié droite récursivement

    int pg = i;     //pg pointe au début du sous-tableau de gauche
    int pd = m + 1; //pd pointe au début du sous-tableau de droite
    int c;          //compteur

// on boucle de i à j pour remplir chaque élément du tableau final fusionné
    for(c = i; c <= j; c++) {
        if(pg == m + 1) { //le pointeur du sous-tableau de gauche a atteint la limite
            tmp[c] = tab[pd];
            pd++;
        }else if (pd == j + 1) { //le pointeur du sous-tableau de droite a atteint la limite
            tmp[c] = tab[pg];
            pg++;
        }else if (tab[pg] < tab[pd]) { //le pointeur du sous-tableau de gauche pointe vers un élément plus petit
            tmp[c] = tab[pg];
            pg++;
        }else {  //le pointeur du sous-tableau de droite pointe vers un élément plus petit
            tmp[c] = tab[pd];
            pd++;
        }
    }

    for(c = i; c <= j; c++) {  //copier les éléments de tmp[] à tab[]
        tab[c] = tmp[c];
    }
    temp();
}
void remplir_aleatoirt_tableau( int tab[], int nb_elt )
/* en paramÃ¨tres : le tableau et le nombre dâ€™Ã©lÃ©ments Ã  utiliser (pas forcÃ©ment tout le tableauâ€¦) */
{
    int i ;

    for (i=0 ; i<nb_elt ; i++)
        tab[i] = rand() % 200000;/* pour obtenir des valeurs comprises entre 0 et 1999 */

    printf("\nNON TRI%cS! : ",144);
    for(i=0;i<nb_elt;i++)
        printf("%d\t",tab[i]);
    printf("\n\n");
}
/* Fin de la d�finition des fonctions de tri */

int main(){
    int nb_entiers; /// nombre d'entiers � entrer
    int i;          /// compteur
    int num;       /// pr�sentation
        printf("Programme : Algorithmes De Tri\n");
        printf("R%calis%c par: MELANGI SONGMENE WILFRIED / Licence 2 \n",130,130,138);
        printf("INSTITU UNIVERSITAIRE SAINT JEAN\n\n");
/// lire nb_entiers
        printf("Donner le nombre d'entiers que vous voulez trier: ");
        scanf("%d",&nb_entiers);
/// allouer la m�moire pour tab[nb_entiers]
    int tab[nb_entiers];/// tableau des entiers
    int tmp[nb_entiers];


/// liste des algorithmes de tri
        printf("\n1. Le tri %c bulle\n",133);
        printf("2. Le tri par s%cl%cction\n",130,130);
        printf("3. Le tri par insertion\n");
        printf("4. Le tri %c bulle D\n",133);
        printf("5. Le tri par s%cl%cction D\n",130,130);
        printf("6. Le tri par insertion D\n");
        printf("7. Le tri Rapide \n");
        printf("8. Le tri Fusion \n\n");

/// remplir tab[nb_entiers] aleatoirement
        printf("TABLEAU D'ELEMENT ALEATOIRE");
        remplir_aleatoirt_tableau(tab,nb_entiers);

/// choisir l'algorithme � appliquer
        do{
            printf("\nVeuillez saisir le num%cro de de l'algorithme de tri %c appliquer: \n\n",130,133);
        scanf("%d",&num);
        if((num>8)||(num<1))
            printf("\n(!) Ce num%cro ne figure pas dans la liste !\n",130);
        }while((num>8)||(num<1));
/// appliquer l'algorithme choisi
       /* if(num==1)  printf("TRI BULLE CROISSANT\n");tri_a_bulle_c(tab,nb_entiers);
        if(num==2)  printf("TRI SELECTION CROISSANT\n");tri_selection_c(tab,nb_entiers);
        if(num==3)  printf("TRI INSERTION CROISSANT\n");tri_insertion_c(tab,nb_entiers);
        if(num==4)  printf("TRI BULLE DECROISSANT\n");tri_a_bulle_d(tab,nb_entiers);
        if(num==5)  printf("TRI SELECTION DECROISSANT\n");tri_selection_d(tab,nb_entiers);
        if(num==6)  printf("TRI INSERTION DECROISSANT\n");tri_insertion_d(tab,nb_entiers);
        if(num==7)  printf("TRI RAPIDE\n");triRapid(tab,0,nb_entiers-1);
        if(num==8)  printf("TRI FUSION\n"); triFusion(0,nb_entiers-1,tab,tmp);
        */
        if(num==1)  printf("TRI BULLE CROISSANT\n");tri_a_bulle_c(tab,nb_entiers);
                    printf("TRI SELECTION CROISSANT\n");tri_selection_c(tab,nb_entiers);
                    printf("TRI INSERTION CROISSANT\n");tri_insertion_c(tab,nb_entiers);
                    printf("TRI BULLE DECROISSANT\n");tri_a_bulle_d(tab,nb_entiers);
                    printf("TRI SELECTION DECROISSANT\n");tri_selection_d(tab,nb_entiers);
                    printf("TRI INSERTION DECROISSANT\n");tri_insertion_d(tab,nb_entiers);
                    printf("TRI RAPIDE\n");triRapid(tab,0,nb_entiers-1);
                    printf("TRI FUSION\n"); triFusion(0,nb_entiers-1,tab,tmp);

/// r�sultat
        printf("\nTRI%cS! : ",144);
        for(i=0;i<nb_entiers;i++)
            printf("%3d\t",tab[i]);
        printf("\n\n");
        system("PAUSE");
        return 0;
}
